# Bot Whatsapp

## Don't Forget Follow [Tiktok](https://www.tiktok.com/@try_catch_), [Instagram](https://www.instagram.com/try.catch.developer/) and [Youtube](https://www.youtube.com/c/TryCatchDev)

# [Watch it on YouTube](https://www.youtube.com/watch?v=p0g8qAFgOLA)

![Preview](/demo/demo1.jpeg)

## Available Scripts

In the project directory, you can run:

#### `npm install`
#### `npm run start` for production
#### `npm run dev` for development
